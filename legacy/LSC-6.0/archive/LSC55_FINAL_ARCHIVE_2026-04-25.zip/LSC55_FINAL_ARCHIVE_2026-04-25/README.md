# LSC 5.5 Final Archive

This archive contains a curated English working package for the final `LSC 5.5`
framework assembled from the source materials in the parent directory.

Archive structure:

- `docs/LSC55_Final_Theory_2026-04-25.md`
  Main English theory document.
- `docs/LSC55_Final_Theory_2026-04-25.pdf`
  PDF of the main theory document.
- `docs/LSC55_Hard_Mathematics_2026-04-25.md`
  Technical mathematical companion.
- `docs/LSC55_Hard_Mathematics_2026-04-25.pdf`
  PDF of the technical mathematical companion.
- `docs/ARCHIVE_MANIFEST.md`
  Selection rationale for the archived sources.
- `sources/core/`
  Core materials from LSC 4.2, 5.0@, and 5.5.
- `sources/history/`
  Historical and superseded branches.
- `sources/simulations/`
  Simulation and case-study support files.

Editorial policy:

- the final mainline is built from `LSC 4.2 ULTRA`, `LSC 5.0@`, and `LSC 5.5`,
- `darkNeutrino` and earlier PBH-regulatory branches are preserved as historical
  context rather than as the central theory,
- unrelated private and non-theoretical files were excluded from the archive,
- the main document is written for coherent preprint-level presentation,
- the mathematical companion pushes the model further toward a defensible
  phenomenological formalism.
