# Instrukcje dla Modelu AI: Symulacja i Analiza LSC4P

Niniejszy dokument zawiera precyzyjne wytyczne dotyczące dalszego przetwarzania danych, implementacji skryptów oraz generowania raportów dla projektu **LSC4P**.

## 1. Kontekst Zadania
Zadaniem jest dokończenie implementacji systemu symulacji pierwotnych czarnych dziur (PBH) w Lokalnej Supergromadzie (LSC). System musi obsługiwać analizę emisji promieniowania Hawkinga oraz wpływ gęstości PBH na tło gamma.

## 2. Implementacja Skryptów (Python 3.11)

### 2.1. Rozszerzenie `src/lsc4p_scan.py`
Należy zaimplementować pełną logikę skanowania parametrów:
-   **Wejście**: Parametry z `config/default_config_example.json`.
-   **Obliczenia**: Wyliczanie widma emisji Hawkinga dla zadanych mas `M_PBH` (10¹⁴ - 10¹⁷ g).
-   **Integracja**: Całkowanie po promieniu `r_min` do `r_max` z uwzględnieniem profilu gęstości `n0`, `r0`.
-   **Wyjście**: Zapis wyników do formatu HDF5 (`results.h5`) dla optymalizacji dużych zbiorów danych.

### 2.2. Uzupełnienie `generate_report.py`
Skrypt powinien automatycznie generować raport PDF na podstawie szablonu LaTeX:
-   Użyj biblioteki `jinja2` do wstrzykiwania wyników (średnie wartości, odchylenia) do pliku `.tex`.
-   Wywołaj `pdflatex` (lub `manus-md-to-pdf` jeśli wolisz Markdown) do finalizacji dokumentu.
-   Dodaj generowanie wykresów widma energii (Energy vs Flux) przy użyciu `matplotlib`.

## 3. Przetwarzanie Danych (CSV/HDF5)
1.  **Walidacja**: Sprawdź, czy dane wejściowe w `data/sample_inputs/` są zgodne ze schematem opisanym w `param_descriptions.json`.
2.  **Agregacja**: Zgrupuj wyniki według masy PBH, aby wyznaczyć optymalne "okno obserwacyjne" dla teleskopów gamma.

## 4. Specyfikacja Techniczna Modelu (LLM Prompting)
Przy generowaniu kodu lub analizie wyników, model powinien:
-   Zachować precyzję naukową (notacja naukowa `1e15` zamiast `1000000000000000`).
-   Stosować typowanie statyczne w Pythonie (`typing`).
-   Zapewnić obsługę błędów dla brakujących plików konfiguracyjnych.

## 5. Lista Kontrolna (Do Wykonania)
- [ ] Implementacja fizyki parowania Hawkinga w `src/`.
- [ ] Automatyzacja generowania wykresów w `generate_report.py`.
- [ ] Weryfikacja spójności jednostek (g, eV, cm) w całym projekcie.
- [ ] Przygotowanie finalnego archiwum `.zip` z kompletną strukturą.

---
*Uwaga: Pliki źródłowe powinny być zgodne ze strukturą zdefiniowaną w pliku `pasted_content.txt`.*
