#!/usr/bin/env python3
"""
Create a Zenodo draft, upload files, and apply metadata.

Usage:
  export ZENODO_TOKEN="your_token_here"
  python upload_to_zenodo.py --file LSC60_ZENODO_RELEASE.pdf

By default this creates a DRAFT only. It does not publish.
To publish intentionally, add: --publish
Test safely first with: --sandbox
"""
import argparse, json, os, sys, requests

def api_base(sandbox=False):
    return "https://sandbox.zenodo.org/api" if sandbox else "https://zenodo.org/api"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", action="append", required=True, help="File to upload. Can be used multiple times.")
    parser.add_argument("--metadata", default="zenodo_metadata.json")
    parser.add_argument("--sandbox", action="store_true", help="Use sandbox.zenodo.org instead of production Zenodo.")
    parser.add_argument("--publish", action="store_true", help="Publish the record after uploading. Use only after manual review.")
    args = parser.parse_args()

    token = os.environ.get("ZENODO_TOKEN")
    if not token:
        print("ERROR: Set ZENODO_TOKEN first.", file=sys.stderr)
        sys.exit(1)

    base = api_base(args.sandbox)
    headers_json = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    headers = {"Authorization": f"Bearer {token}"}

    with open(args.metadata, "r", encoding="utf-8") as f:
        metadata = json.load(f)

    print("Creating deposition draft...")
    r = requests.post(f"{base}/deposit/depositions", headers=headers_json, data=json.dumps({}))
    r.raise_for_status()
    dep = r.json()
    dep_id = dep["id"]
    bucket = dep["links"]["bucket"]
    print(f"Draft created: deposition id {dep_id}")

    print("Applying metadata...")
    r = requests.put(f"{base}/deposit/depositions/{dep_id}", headers=headers_json, data=json.dumps(metadata))
    r.raise_for_status()

    for path in args.file:
        filename = os.path.basename(path)
        print(f"Uploading {filename}...")
        with open(path, "rb") as fp:
            r = requests.put(f"{bucket}/{filename}", data=fp, headers=headers)
        r.raise_for_status()

    print("Draft ready.")
    print(f"Inspect it on Zenodo before publishing: {dep.get('links', {}).get('html', 'check your Zenodo uploads')}")

    if args.publish:
        print("Publishing...")
        r = requests.post(f"{base}/deposit/depositions/{dep_id}/actions/publish", headers=headers)
        r.raise_for_status()
        print("Published:")
        print(json.dumps(r.json(), indent=2))
    else:
        print("Not published. Add --publish only after reviewing the draft.")

if __name__ == "__main__":
    main()
