# LSC 6.0 Zenodo Release Package

Files:
- LSC60_ZENODO_RELEASE.pdf: clean Zenodo working-paper PDF.
- zenodo_metadata.json: suggested Zenodo metadata.
- upload_to_zenodo.py: optional API upload script.

Recommended Zenodo workflow:
1. Upload manually first, or test the script on https://sandbox.zenodo.org.
2. If continuing the exact LSC 4.2 record lineage, use Zenodo's "New version" feature on the existing record.
3. If publishing a separate LSC 6.0 record, use `related_identifiers` with relation `isDerivedFrom` pointing to DOI 10.5281/zenodo.19602045.
4. Do not auto-publish with a script until you preview the draft.

Script:
    pip install requests
    export ZENODO_TOKEN="..."
    python upload_to_zenodo.py --file LSC60_ZENODO_RELEASE.pdf

Safe test:
    python upload_to_zenodo.py --sandbox --file LSC60_ZENODO_RELEASE.pdf
